package com.drblockheadmc.db.procedures;

public class TardisLoadStoneOnBlockRightClickedProcedure {
	public static void execute() {
	}
}
