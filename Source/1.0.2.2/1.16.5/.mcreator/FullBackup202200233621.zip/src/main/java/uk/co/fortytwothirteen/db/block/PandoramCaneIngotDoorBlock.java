
package uk.co.fortytwothirteen.db.block;

import uk.co.fortytwothirteen.db.itemgroup.DocBlocksItemGroup;
import uk.co.fortytwothirteen.db.DbModElements;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.state.properties.DoubleBlockHalf;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.loot.LootContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.BlockItem;
import net.minecraft.block.material.Material;
import net.minecraft.block.SoundType;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;

import java.util.List;
import java.util.Collections;

@DbModElements.ModElement.Tag
public class PandoramCaneIngotDoorBlock extends DbModElements.ModElement {
	@ObjectHolder("db:pandoram_cane_ingot_door")
	public static final Block block = null;

	public PandoramCaneIngotDoorBlock(DbModElements instance) {
		super(instance, 70);
	}

	@Override
	public void initElements() {
		elements.blocks.add(() -> new CustomBlock());
		elements.items.add(() -> new BlockItem(block, new Item.Properties().group(DocBlocksItemGroup.tab)).setRegistryName(block.getRegistryName()));
	}

	public static class CustomBlock extends DoorBlock {
		public CustomBlock() {
			super(Block.Properties.create(Material.WOOD).sound(SoundType.METAL).hardnessAndResistance(6f, 17f).setLightLevel(s -> 0));
			setRegistryName("pandoram_cane_ingot_door");
		}

		@Override
		public List<ItemStack> getDrops(BlockState state, LootContext.Builder builder) {
			if (state.get(BlockStateProperties.DOUBLE_BLOCK_HALF) != DoubleBlockHalf.LOWER)
				return Collections.emptyList();
			List<ItemStack> dropsOriginal = super.getDrops(state, builder);
			if (!dropsOriginal.isEmpty())
				return dropsOriginal;
			return Collections.singletonList(new ItemStack(this, 1));
		}
	}
}
