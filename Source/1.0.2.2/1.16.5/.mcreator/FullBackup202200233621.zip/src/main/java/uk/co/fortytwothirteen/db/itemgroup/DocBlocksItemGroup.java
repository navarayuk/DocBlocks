
package uk.co.fortytwothirteen.db.itemgroup;

import uk.co.fortytwothirteen.db.item.CreativeIconItem;
import uk.co.fortytwothirteen.db.DbModElements;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

@DbModElements.ModElement.Tag
public class DocBlocksItemGroup extends DbModElements.ModElement {
	public DocBlocksItemGroup(DbModElements instance) {
		super(instance, 4);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabdoc_blocks") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(CreativeIconItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundImageName("item_search.png");
	}

	public static ItemGroup tab;
}
