package com.drblockheadmc.db.procedures;

import java.util.Map;

public class TardisLoadStoneOnBlockRightClickedProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {

	}
}
